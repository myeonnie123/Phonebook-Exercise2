package com.addressbook.android.model

import java.io.Serializable

/**
 * Created by Administrator on 3/15/18.
 */


data class UserLoginDetail(var Password: String, var Email: String) : Serializable {


}




